package com.trapline.app

import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/* ============================ KITE CLIENT ============================ */

class Kite(private val apiKey: String, private val apiSecret: String) {
    var accessToken: String? = null; private set
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
    private val base = "https://api.kite.trade"

    fun loginUrl() = "https://kite.zerodha.com/connect/login?v=3&api_key=$apiKey"

    private fun sha256(s: String) =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    suspend fun createSession(requestToken: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val body = FormBody.Builder()
                .add("api_key", apiKey).add("request_token", requestToken)
                .add("checksum", sha256(apiKey + requestToken + apiSecret)).build()
            val req = Request.Builder().url("$base/session/token")
                .header("X-Kite-Version", "3").post(body).build()
            http.newCall(req).execute().use { resp ->
                val json = JSONObject(resp.body?.string().orEmpty())
                if (json.optString("status") == "success") {
                    accessToken = json.getJSONObject("data").getString("access_token")
                    Result.success(accessToken!!)
                } else Result.failure(Exception(json.optString("message", "login failed")))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    private fun authedGet(path: String): JSONObject {
        val req = Request.Builder().url("$base$path")
            .header("X-Kite-Version", "3")
            .header("Authorization", "token $apiKey:$accessToken").get().build()
        http.newCall(req).execute().use { return JSONObject(it.body?.string().orEmpty()) }
    }

    suspend fun ltp(instrument: String): Result<Double> = withContext(Dispatchers.IO) {
        try {
            val enc = java.net.URLEncoder.encode(instrument, "UTF-8")
            val json = authedGet("/quote/ltp?i=$enc")
            if (json.optString("status") == "success")
                Result.success(json.getJSONObject("data").getJSONObject(instrument).getDouble("last_price"))
            else Result.failure(Exception(json.optString("message", "ltp failed")))
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun placeOrder(
        exchange: String, tradingSymbol: String, transactionType: String,
        quantity: Int, product: String = "MIS", orderType: String = "MARKET"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val fb = FormBody.Builder()
                .add("tradingsymbol", tradingSymbol).add("exchange", exchange)
                .add("transaction_type", transactionType).add("order_type", orderType)
                .add("quantity", quantity.toString()).add("product", product).add("validity", "DAY")
            val req = Request.Builder().url("$base/orders/regular")
                .header("X-Kite-Version", "3")
                .header("Authorization", "token $apiKey:$accessToken").post(fb.build()).build()
            http.newCall(req).execute().use { resp ->
                val json = JSONObject(resp.body?.string().orEmpty())
                if (json.optString("status") == "success")
                    Result.success(json.getJSONObject("data").getString("order_id"))
                else Result.failure(Exception(json.optString("message", "order rejected")))
            }
        } catch (e: Exception) { Result.failure(e) }
    }
}

/* ============================ ENGINE ============================ */

data class Candle(val start: Long, val open: Double, var high: Double, var low: Double, var close: Double)
enum class Verdict { GO, WAIT, NO_TRADE }
enum class Dir { BEAR, BULL }

class CandleSeries(private val bucketMs: Long = 5 * 60_000L) {
    val candles = mutableListOf<Candle>()
    private var cumPV = 0.0; private var cumN = 0.0
    fun onPrice(ts: Long, price: Double) {
        val bucket = ts - (ts % bucketMs)
        val last = candles.lastOrNull()
        if (last == null || last.start != bucket) candles.add(Candle(bucket, price, price, price, price))
        else { last.high = maxOf(last.high, price); last.low = minOf(last.low, price); last.close = price }
        cumPV += price; cumN += 1.0
    }
    fun vwap() = if (cumN > 0) cumPV / cumN else (candles.lastOrNull()?.close ?: 0.0)
    fun last() = candles.lastOrNull()
    fun sessionHigh() = candles.maxOfOrNull { it.high } ?: 0.0
    fun sessionLow() = candles.minOfOrNull { it.low } ?: 0.0
}

data class Rule(val key: String, val label: String, var checked: Boolean = false)

class Strategy {
    var dir = Dir.BEAR
    val bearRules = listOf(
        Rule("morning", "Morning push UP, then stalled"),
        Rule("breadth", "Move NOT broad-based (weak breadth)"),
        Rule("stretch", "Price was stretched above VWAP"),
        Rule("below", "Closed BELOW VWAP (5-min)"),
        Rule("retest", "VWAP retest FAILED"),
        Rule("chain", "Option chain confirms (call OI build)"),
        Rule("event", "No event landmine in window"),
        Rule("window", "Time window 12:30-14:45")
    )
    val bullRules = listOf(
        Rule("morning", "Morning flush DOWN, then stalled"),
        Rule("breadth", "Selling NOT broad-based"),
        Rule("stretch", "Price was stretched below VWAP"),
        Rule("above", "Reclaimed ABOVE VWAP (5-min)"),
        Rule("retest", "VWAP retest HELD"),
        Rule("chain", "Option chain confirms (put OI build)"),
        Rule("event", "No event landmine in window"),
        Rule("window", "Time window 12:30-14:45")
    )
    fun rules() = if (dir == Dir.BEAR) bearRules else bullRules
    fun autoDetect(s: CandleSeries) {
        val c = s.last() ?: return; val v = s.vwap()
        if (dir == Dir.BEAR) {
            bearRules.first { it.key == "below" }.checked = c.close < v
            bearRules.first { it.key == "stretch" }.checked = s.sessionHigh() > v * 1.003
        } else {
            bullRules.first { it.key == "above" }.checked = c.close > v
            bullRules.first { it.key == "stretch" }.checked = s.sessionLow() < v * 0.997
        }
    }
    fun confirmedCount() = rules().count { it.checked }
    fun allConfirmed() = rules().all { it.checked }
}

class RiskGovernor {
    var capital = 100_000.0; var riskPerTradePct = 1.0; var dailyLossStopPct = 2.0
    var maxTradesPerDay = 2; var roundTripCostPerLot = 60.0; var minRR = 1.5
    var tradesToday = 0; var lossToday = 0.0
    fun budget() = capital * riskPerTradePct / 100.0
    fun dailyStop() = capital * dailyLossStopPct / 100.0
    fun deskClosed() = tradesToday >= maxTradesPerDay || lossToday >= dailyStop()

    data class Sizing(val rr: Double, val lots: Int, val totalRisk: Double, val totalReward: Double)
    fun size(lotSize: Int, entry: Double, stop: Double, target: Double): Sizing {
        val rUnit = abs(entry - stop); val rewUnit = abs(target - entry)
        val rr = if (rUnit > 0) rewUnit / rUnit else 0.0
        val riskPerLot = rUnit * lotSize + roundTripCostPerLot
        val lots = if (riskPerLot > 0) (budget() / riskPerLot).toInt() else 0
        return Sizing(rr, lots, lots * riskPerLot, lots * (rewUnit * lotSize) - lots * roundTripCostPerLot)
    }
    fun verdict(st: Strategy, s: Sizing): Pair<Verdict, List<String>> {
        val b = mutableListOf<String>()
        if (!st.allConfirmed()) b.add("Checklist incomplete")
        if (s.rr < minRR) b.add("R:R ${"%.1f".format(s.rr)} below $minRR")
        if (s.lots < 1) b.add("Stop too wide - 0 lots fit budget")
        if (tradesToday >= maxTradesPerDay) b.add("Max trades reached")
        if (lossToday >= dailyStop()) b.add("Daily loss stop hit")
        val v = when { b.isEmpty() -> Verdict.GO; st.confirmedCount() > 0 -> Verdict.WAIT; else -> Verdict.NO_TRADE }
        return v to b
    }
}

/* ============================ UI ============================ */

private val INK = Color(0xFF0B0E14); private val PANEL = Color(0xFF141A25)
private val LINE = Color(0xFF26303F); private val TXT = Color(0xFFE7ECF3)
private val MUT = Color(0xFF8A97AC); private val GO = Color(0xFF2EE6A6)
private val WAIT = Color(0xFFF4B740); private val NO = Color(0xFFFF5D6C); private val ACC = Color(0xFF7AA2FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var apiKey by remember { mutableStateOf("") }
    var apiSecret by remember { mutableStateOf("") }
    var kite by remember { mutableStateOf<Kite?>(null) }
    var showLogin by remember { mutableStateOf(false) }
    var loggedIn by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Surface(color = INK, modifier = Modifier.fillMaxSize()) {
        when {
            showLogin && kite != null -> KiteWebLogin(kite!!) { token ->
                scope.launch {
                    status = "Exchanging token..."
                    kite!!.createSession(token)
                        .onSuccess { loggedIn = true; showLogin = false; status = "Connected" }
                        .onFailure { status = it.message ?: "Login failed"; showLogin = false }
                }
            }
            loggedIn && kite != null -> Dashboard(kite!!)
            else -> LoginSetup(apiKey, apiSecret, status, { apiKey = it }, { apiSecret = it }) {
                if (apiKey.isNotBlank() && apiSecret.isNotBlank()) {
                    kite = Kite(apiKey.trim(), apiSecret.trim()); showLogin = true
                } else status = "Enter your Kite API key and secret"
            }
        }
    }
}

@Composable
fun LoginSetup(apiKey: String, apiSecret: String, status: String,
               onKey: (String) -> Unit, onSecret: (String) -> Unit, onConnect: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center) {
        Text("TRAPLINE", color = TXT, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
        Text("Connect your Zerodha Kite account", color = MUT, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        Field("Kite API key", apiKey, onKey)
        Field("Kite API secret", apiSecret, onSecret)
        Spacer(Modifier.height(8.dp))
        Button(onClick = onConnect, colors = ButtonDefaults.buttonColors(containerColor = GO),
            modifier = Modifier.fillMaxWidth()) {
            Text("LOGIN WITH ZERODHA", color = INK, fontWeight = FontWeight.Bold)
        }
        if (status.isNotEmpty()) { Spacer(Modifier.height(12.dp)); Text(status, color = WAIT, fontSize = 12.sp) }
        Spacer(Modifier.height(18.dp))
        Text("Needs a paid Kite Connect subscription (kite.trade). Set your app's Redirect URL to " +
            "https://127.0.0.1 - this screen captures the login token from that redirect.",
            color = MUT, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
fun KiteWebLogin(kite: Kite, onToken: (String) -> Unit) {
    AndroidView(factory = { ctx ->
        WebView(ctx).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                fun capture(url: String?): Boolean {
                    if (url == null) return false
                    val t = Uri.parse(url).getQueryParameter("request_token")
                    if (!t.isNullOrBlank()) { onToken(t); return true }
                    return false
                }
                override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?) =
                    capture(r?.url?.toString())
                override fun onPageStarted(v: WebView?, url: String?, f: android.graphics.Bitmap?) { capture(url) }
            }
            loadUrl(kite.loginUrl())
        }
    }, modifier = Modifier.fillMaxSize())
}

@Composable
fun Dashboard(kite: Kite) {
    val series = remember { CandleSeries() }
    val strategy = remember { Strategy() }
    val gov = remember { RiskGovernor() }
    var tick by remember { mutableStateOf(0L) }
    var price by remember { mutableStateOf(0.0) }
    var err by remember { mutableStateOf("") }
    var instrument by remember { mutableStateOf("NSE:NIFTY 50") }
    var lotSize by remember { mutableStateOf(65) }
    var optionSymbol by remember { mutableStateOf("") }
    var entry by remember { mutableStateOf("120") }
    var stop by remember { mutableStateOf("95") }
    var target by remember { mutableStateOf("175") }
    var confirmOrder by remember { mutableStateOf(false) }
    var orderMsg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(instrument) {
        while (true) {
            kite.ltp(instrument).onSuccess { p ->
                price = p; series.onPrice(System.currentTimeMillis(), p)
                strategy.autoDetect(series); tick++; err = ""
            }.onFailure { err = it.message ?: "feed error" }
            delay(2000)
        }
    }

    val sizing = gov.size(lotSize, entry.toDoubleOrNull() ?: 0.0,
        stop.toDoubleOrNull() ?: 0.0, target.toDoubleOrNull() ?: 0.0)
    val (verdict, blockers) = gov.verdict(strategy, sizing)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TRAPLINE", color = TXT, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            Text("LIVE  ${"%.2f".format(price)}", color = GO, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        }
        Spacer(Modifier.height(14.dp))
        val gateColor = when (verdict) { Verdict.GO -> GO; Verdict.WAIT -> WAIT; else -> NO }
        Box(Modifier.fillMaxWidth().border(1.dp, gateColor, RoundedCornerShape(16.dp))
            .background(PANEL, RoundedCornerShape(16.dp)).padding(22.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(verdict.name.replace("_", " "), color = gateColor, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
                Spacer(Modifier.height(8.dp))
                Text(if (blockers.isEmpty()) "All confirmed - ${sizing.lots} lot(s) - ${"%.1f".format(sizing.rr)}R"
                    else blockers.joinToString(" - "), color = MUT, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row {
            DirChip("BEAR - PUT", strategy.dir == Dir.BEAR) { strategy.dir = Dir.BEAR; tick++ }
            Spacer(Modifier.width(8.dp))
            DirChip("BULL - CALL", strategy.dir == Dir.BULL) { strategy.dir = Dir.BULL; tick++ }
        }
        Spacer(Modifier.height(8.dp))
        Row {
            InstChip("NIFTY", instrument == "NSE:NIFTY 50") { instrument = "NSE:NIFTY 50"; lotSize = 65 }
            Spacer(Modifier.width(8.dp))
            InstChip("BANKNIFTY", instrument == "NSE:NIFTY BANK") { instrument = "NSE:NIFTY BANK"; lotSize = 30 }
        }
        Spacer(Modifier.height(14.dp))
        key(tick) { Chart(series) }
        Text("VWAP ${"%.2f".format(series.vwap())}  -  candles ${series.candles.size}",
            color = MUT, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        if (err.isNotEmpty()) Text(err, color = NO, fontSize = 11.sp)
        Spacer(Modifier.height(14.dp))
        SectionLabel("CONFIRMATIONS")
        key(tick) {
            strategy.rules().forEach { r ->
                Row(Modifier.fillMaxWidth().clickable { r.checked = !r.checked; tick++ }.padding(vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(20.dp).background(if (r.checked) GO else PANEL, RoundedCornerShape(6.dp))
                        .border(1.dp, LINE, RoundedCornerShape(6.dp)))
                    Spacer(Modifier.width(11.dp))
                    Text(r.label, color = TXT, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        SectionLabel("POSITION & RISK")
        Field("Option tradingsymbol (NFO) e.g. NIFTY2561925100PE", optionSymbol) { optionSymbol = it }
        Row {
            Box(Modifier.weight(1f)) { Field("Entry", entry) { entry = it } }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) { Field("Stop", stop) { stop = it } }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) { Field("Target", target) { target = it } }
        }
        InfoLine("Affordable size", "${sizing.lots} lot  (qty ${sizing.lots * lotSize})")
        InfoLine("Capital at risk", "Rs ${sizing.totalRisk.toInt()}")
        InfoLine("Reward if target", "Rs ${sizing.totalReward.toInt()}")
        InfoLine("Reward : Risk", "${"%.2f".format(sizing.rr)} : 1")
        Spacer(Modifier.height(14.dp))
        Button(onClick = { confirmOrder = true },
            enabled = verdict == Verdict.GO && optionSymbol.isNotBlank() && !gov.deskClosed(),
            colors = ButtonDefaults.buttonColors(containerColor = GO, disabledContainerColor = PANEL),
            modifier = Modifier.fillMaxWidth()) {
            Text(if (gov.deskClosed()) "DESK CLOSED FOR TODAY" else "FIRE ORDER (${sizing.lots} LOT)",
                color = if (verdict == Verdict.GO && !gov.deskClosed()) INK else MUT, fontWeight = FontWeight.Bold)
        }
        if (orderMsg.isNotEmpty()) {
            Spacer(Modifier.height(10.dp)); Text(orderMsg, color = ACC, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text("Semi-auto by design: the engine finds the setup, you confirm the fire.",
            color = MUT, fontSize = 11.sp, lineHeight = 16.sp)
        Spacer(Modifier.height(30.dp))
    }

    if (confirmOrder) {
        AlertDialog(onDismissRequest = { confirmOrder = false },
            confirmButton = {
                TextButton(onClick = {
                    confirmOrder = false
                    scope.launch {
                        kite.placeOrder("NFO", optionSymbol.trim(), "BUY", sizing.lots * lotSize)
                            .onSuccess { gov.tradesToday++; orderMsg = "Order placed - id $it" }
                            .onFailure { orderMsg = "Rejected: ${it.message}" }
                    }
                }) { Text("FIRE", color = GO) }
            },
            dismissButton = { TextButton(onClick = { confirmOrder = false }) { Text("Cancel", color = MUT) } },
            title = { Text("Confirm live order", color = TXT) },
            text = { Text("BUY ${sizing.lots * lotSize} qty of $optionSymbol (NFO, MIS, MARKET). " +
                "Capital at risk approx Rs ${sizing.totalRisk.toInt()}. This is a REAL order.", color = MUT) },
            containerColor = PANEL)
    }
}

@Composable
fun Chart(series: CandleSeries) {
    Canvas(Modifier.fillMaxWidth().height(180.dp)
        .background(Color(0xFF10141D), RoundedCornerShape(10.dp)).padding(8.dp)) {
        val cs = series.candles
        if (cs.isEmpty()) return@Canvas
        val hi = cs.maxOf { it.high }; val lo = cs.minOf { it.low }
        val range = (hi - lo).takeIf { it > 0 } ?: 1.0
        val w = size.width; val h = size.height; val cw = w / cs.size
        fun y(v: Double) = (h - (v - lo) / range * h).toFloat()
        val vy = y(series.vwap())
        drawLine(ACC, Offset(0f, vy), Offset(w, vy), strokeWidth = 1.5f)
        cs.forEachIndexed { i, c ->
            val cx = i * cw + cw / 2
            val col = if (c.close >= c.open) GO else NO
            drawLine(col, Offset(cx, y(c.high)), Offset(cx, y(c.low)), strokeWidth = 1.5f)
            val top = y(maxOf(c.open, c.close)); val bot = y(minOf(c.open, c.close))
            drawRect(col, Offset(i * cw + cw * 0.2f, top), Size(cw * 0.6f, (bot - top).coerceAtLeast(1f)))
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onChange,
        label = { Text(label, color = MUT, fontSize = 11.sp) }, singleLine = true,
        textStyle = TextStyle(color = TXT, fontFamily = FontFamily.Monospace),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ACC, unfocusedBorderColor = LINE,
            focusedContainerColor = PANEL, unfocusedContainerColor = PANEL),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
}

@Composable
fun DirChip(text: String, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.background(if (on) ACC else PANEL, RoundedCornerShape(10.dp))
        .border(1.dp, LINE, RoundedCornerShape(10.dp)).clickable { onClick() }
        .padding(horizontal = 14.dp, vertical = 9.dp)) {
        Text(text, color = if (on) INK else MUT, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun InstChip(text: String, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.background(if (on) Color(0xFF1A2231) else PANEL, RoundedCornerShape(10.dp))
        .border(1.dp, if (on) ACC else LINE, RoundedCornerShape(10.dp)).clickable { onClick() }
        .padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, color = if (on) TXT else MUT, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = MUT, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))
}

@Composable
fun InfoLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(k, color = MUT, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Text(v, color = TXT, fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
